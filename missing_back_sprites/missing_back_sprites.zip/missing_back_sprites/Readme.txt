Credits and Aknowledgements:

These were free to use: 
https://www.smogon.com/forums/threads/the-gen-4-style-gen-5-and-beyond-backsprite-resource.3687625/

https://www.smogon.com/forums/threads/x-y-sprite-project.3486712/page-130#post-6674962

Gourgeist Forms Sprites Gen 4 DS Style 80x80 px
by
Prodigal96

All four forms or sizes of Gourgeist in Gen 4 DS style, 80x80px. Upscale to 160x160px for Pokemon Essentials.

Front Sprite base credit to MrDollSteak on the Gen VI: DS-Style 64x64 Pokemon Sprite Resource from Pokecommunity. I recolored and resized his sprites to better fit the 80x80 size.
Back sprite base credit to briochee on the Gen 4-Style Gen 5 and Beyond Backsprite Resource from Smogon. I recolored and resized his main sprite to get the other sizes.
------------------------------------------------------------------------------------------------------
All contributors to the sprites and this project (please thank and credit them for their work!):
------------------------------------------------------------------------------------------------------
@ Dreadwing93: *All Unova Pokemon (Victini-Genesect)(repubished by Aki)
	       *Most Kalos Pokemon:
				-Chespin line
				-Fennekin line
				-Froakie line
				-Bunnelby line
				-Fletchling line
				-Scatterbug line
				-Vivillon forms
				-Litleo line
				-Flabebe line + colors
				-Honedge line
				-Spritzee
				-Inkay line
				-Skrelp line
				-Helioptile line
				-Tyrunt line
				-Amaura line
				-Carbink
@ Prodigal96:  *Some Alolan Forms:
				-Alolan Raticate
				-Alolan Meowth
				-Alolan Grimer line
	       *Some Galarian Forms:
				-Galarian Meowth
				-Galarian Slowpoke line
	       *Some Galar Pokemon:
				-Gossifleur line
				-Yamper line
				-Arrokuda
				-Grimmsnarl
				-Stonjourner
				-Eiscue forms
				-Indeedee forms
				-Copperajah
				-Eternatus
				-Zarude forms
	       *Some Alola Pokemon:
				-Wishiwashi
				-Bruxish
				-Bewear
				-Nihilego
				-Buzzwole
				-Pheromosa
				-Xurkitree
				-Celesteela
				-Kartana
				-Guzzlord
				-Poipole line
				-Stakataka
				-Blacephalon
	       *Some Megas:
				-Mega Venusaur
				-Mega Charizard X + Y
				-Mega Blastoise
				-Mega Beedrill
				-Mega Pidgeot
				-Mega Alakazam
				-Mega Gengar
				-Mega Kangaskhan
				-Mega Pinsir
				-Mega Gyarados
				-Mega Aerodactyl
				-Mega Mewtwo X + Y
				-Mega Ampharos
				-Mega Scizor
				-Mega Houndoom
				-Mega Sceptile
				-Mega Blaziken
				-Mega Swampert
				-Mega Manectric
				-Mega Altaria
				-Mega Banette
				-Mega Absol
				-Primal Kyogre
				-Primal Groudon
	       *Some Gigantamax Forms:
				-Gigantamax Venusaur
				-Gigantamax Charizard
				-Gigantamax Blastoise
				-Gigantamax Butterfree
				-Gigantamax Pikachu
				-Gigantamax Meowth
				-Gigantamax Machamp
				-Gigantamax Gengar
				-Gigantamax Kingler
				-Gigantamax Lapras
				-Gigantamax Eevee
				-Gigantamax Snorlax
				-Gigantamax Grimmsnarl
				-Gigantamax Copperajah
	       *Barbaracle edits
@ MM980:       *Some Alola Pokemon:
				-Dartrix
				-Decidueye
	       *Some Kalos Pokemon:
				-Ash-Greninja
				-Eternal Flower Floette
				-Barbaracle
				-Goodra
				-Trevenant
				-Xerneas
				-Yveltal
				-Zygarde Forms
				-Volcanion
	       *Galarian Yamask
	       *Mega Gardevoir
@ 44tim44:     *Sylveon
@ Gnomowladny: *Some Megas:
				-Mega Sableye
				-Mega Mawile
				-Mega Glalie
				-Mega Lopunny
				-Mega Audino
	       *Some Alolan Pokemon:
				-Rowlet
				-Mimikyu
@ MetalFlygon (republished by Zygoat): *Some Alola Pokemon: 
				                   -Rockruff line
				                   -Salandit line
				                   -Meltan
	      			       *Some Galar Pokemon:
						   -Nickit line
				                   -Clobbopus line
				                   -Sirfetch'd
				                   -Mr. Rime
 				       *Some Alolan Forms:
						   -Alolan Ratatta
						   -Alolan Raichu
						   -Alolan Sandshrew line
						   -Alolan Vulpix line
						   -Alolan Diglett line
						   -Alolan Persian
						   -Alolan Geodude line
						   -Alolan Exeggutor
						   -Alolan Marowak
	     			       *Some Galarian Forms:
						   -Galarian Ponyta line
				                   -Galarian Farfetch'd
				                   -Galarian Weezing
				                   -Galarian Mr. Mime
				                   -Galarian Corsola
@ Zygoat:     *Some Megas:
				-Mega Heracross
				-Mega Medicham
				-Mega Garchomp
				-Mega Lucario
	      *Some Galar Pokemon:
				-Obstagoon
				-Alcremie
	      *Pikachu Libre
	      *Galarian Zigzagoon and Linoone
@ WolfPP:     *Some Galarian Pokemon:
		  		-Kubfu line
				-Dreepy
				-Inteleon
				-Galarian Zapdos
				-Galarian Moltres
@ lichenprincess: *Some Galarian Pokemon:
				-Thwackey
				-Raboot
				-Drizzile
				-Hatterene
				-Drakloak
				-Dragapult
				-Regieleki
	  	  *Galarian Articuno
                  *Dhelmise
@ BiggusWeeabus: *Rookidee line
@ ChromusSama:   *Phantump
@ briochee       *Hawlucha
	         *Kleavor
	         *Ursaluna
		 *Some Alola Pokemon
				-Litten
				-Incineroar
				-Popplio line
				-Pikipek line
				-Yungoos line
				-Grubbin line
				-Morelull
				-Jangmo-o line
				-Zeraora
@ Mak:           *Skiddo
	         *Some Alola Pokemon
				-Crabrawler
				-Mudbray line
				-Dewpider line
	         *Some Galar Pokemon
				-Sizzlipede line
				-Sinistea
				-Impidimp
				-Morgrem
				-Frosmoth
	         *Galarian Stunfisk
	         *Goomy and Sliggoo forms
@ KRLW890        *Some Galar Pokemon
				-Rolycoly line
				-Applin line
				-Perrserker
				-Cursola
	         *Hisuian Typhlosion
	         *Hisuian Decidueye
	         *Clauncher line
@ Loafus022: 	 *Basculegion forms
@ Sopita_Yorita: *Hisuian Growlithe
@ lennybitao:    *Rillaboom
	         *Hisuian Arcanine
	         *Zeraora
	         *Some Kalos Pokemon
				-Pancham
				-Aromatisse
				-Swirlix line
				-Noibat line
				-Hoopa (Unbound)
@ Scept:    	 *Gen 9 Starters
				-Sprigatito
				-Fuecoco
				-Quaxly
@ Travis:        *Some Hisui Pokemon
				-Sneasler
				-Overqwil
@ MrEoncito:     *Some Galar Pokemon
				-Grookey
				-Scorbunny
				-Cinderace
				-Sobble
	         *Some Megas:
				-Mega Latias
				-Mega Latios
				-Mega Gallade
	         *Silvally
@ IDesbas/Angy:  *Some Megas:
				-Mega Steelix
				-Mega Tyranitar
@ I'mBadAtStuff: *Dedenne
@ SkidMarc25:    *Pangoro
@ Mesayas:	 *Some Paldea Pokemon
				-Cetitan
				-Cyclizar
@ PorousMist326: *Runerigus
	         *Marshadow
	         *Gigantamax Inteleon
	         *Galarian Darumaka line
	         *Skwovet line
	         *Blipbug line
	         *Fairy-type Arceus
	         *HOME Shiny Castform forms
	         *Torracat
	         *Sandyghast line
	         *Cutiefly
	         *Binacle
	         *Klefki
	         *Xerneas forms
	         *Yveltal
	         *Zygarde
	         *Hoopa
	         *Mega Sharpedo
		 *Pikachu Forms:
				-Black Tip
				-Partner Pikachu
		 *Eevee Forms:
				-Female Eevee
				-Partner Eevee
                 *Hisuian Qwilfish
                 *White-striped Basculin
	         *Missing shinies
	         *Recolor edits
	         *Compiling of sprites
------------------------------------------------------------------------------------------------------
Special thanks to the following:
------------------------------------------------------------------------------------------------------
@ leParagon:     *Inspiration and bases of many sprites
@ DS-style Gen VII and Beyong Pokemon Sprite Repository: *Inspiration and bases of many sprites
@ Smogon Art Projects: *Inspiration and bases of many sprites
------------------------------------------------------------------------------------------------------
Links to their work:
https://www.deviantart.com/dreadwing93/gallery/50014648/pokemon
https://www.deviantart.com/prodigal96
https://www.pokecommunity.com/member.php?u=902180
https://www.deviantart.com/44tim44
https://www.deviantart.com/gnomowladny
https://www.pokecommunity.com/member.php?u=757925
https://www.reddit.com/user/metalflygon08/posts/
https://www.pokecommunity.com/member.php?u=730428
https://www.pokecommunity.com/member.php?u=756239
https://www.pokecommunity.com/member.php?u=844285
https://www.pokecommunity.com/member.php?u=769478
https://www.smogon.com/forums/forums/smeargles-laptop.325/
https://www.pokecommunity.com/showthread.php?t=368703
https://www.deviantart.com/leparagon
https://www.deviantart.com/lennybitao
https://www.deviantart.com/limitdistortion
https://www.pokecommunity.com/member.php?u=892332
https://reliccastle.com/members/3/
https://reliccastle.com/members/74/
https://twitter.com/IDesbas
------------------------------------------------------------------------------------------------------
